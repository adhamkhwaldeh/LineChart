enum MonitoringTypeEnum {
  solar,
  house,
  battery,
}