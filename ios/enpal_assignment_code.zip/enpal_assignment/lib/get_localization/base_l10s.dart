class BaseL10S {
  static const String enpalApp = "Enpal App";

  static const String solar = "solar";

  static const String house = "house";

  static const String battery = "battery";

  static const String arabic = "Arabic";

  static const String english = "English";

  static const String german = "German";

  static const String kiloWatt = "kiloWatt";

  static const String watts = "Watts";

  static const String kilo = "kilo";

  static const String time = "time";

  static const String unexpectedErrorHappened = "Unexpected_Error_Happened";

  static const String noMoreData = "No more data";

  static const String internetIssue = "Internet issue";

  static const String reTry = "reTry";

  static const String notAuthorized = "Not_Authorized";

  static const String request = "Request";

  static const String language = "Language";

  static const String changeLanguage = "ChangeLanguage";
}
