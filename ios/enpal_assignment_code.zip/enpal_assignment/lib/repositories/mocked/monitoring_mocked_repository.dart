import 'package:enpal_assignment/api_services/api_service.dart';
import 'package:enpal_assignment/repositories/imonitoring_repository.dart';
import 'package:injectable/injectable.dart';
import 'package:mocktail/mocktail.dart';

@lazySingleton
class MonitoringMockedRepository extends Mock implements IMonitoringRepository {
  // final ApiService apiInterface;
  // MonitoringMockedRepository(
  //   this.apiInterface,
  // );
}
